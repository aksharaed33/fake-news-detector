# app.py

import streamlit as st
import pickle

# Load saved model and vectorizer
with open("fake_news_model.pkl", "rb") as f:
    model = pickle.load(f)

with open("tfidf_vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)

# App layout
st.set_page_config(page_title="Fake News Detector", layout="wide")
st.title("📰 Fake News Detection System")

# User input
text_input = st.text_area("Enter a news article or statement to check if it's Fake or Real:")

if st.button("Analyze"):
    if text_input.strip() == "":
        st.warning("⚠️ Please enter some content first.")
    else:
        vectorized_input = vectorizer.transform([text_input])
        prediction = model.predict(vectorized_input)[0]
        if prediction == "FAKE":
            st.error("❌ This news is likely FAKE.")
        else:
            st.success("✅ This news is likely REAL.")
