# combine_data.py

import pandas as pd

# Load datasets
true_df = pd.read_csv("True.csv")
true_df['label'] = "REAL"

fake_df = pd.read_csv("Fake.csv")
fake_df['label'] = "FAKE"

# Combine and shuffle
df = pd.concat([true_df, fake_df])
df = df[['title', 'text', 'label']]  # Only keep necessary columns
df = df.sample(frac=1).reset_index(drop=True)

# Save combined dataset
df.to_csv("news.csv", index=False)

print("✅ Dataset combined and saved to news.csv")
